import flask
from flask import Flask, redirect , url_for, render_template, request, jsonify
from flask.wrappers import Response
from numpy import roots
import fetchData
from flask import request, jsonify
import json
import requests
import pandas as pd
import time


app = flask.Flask(__name__)
app.config["DEBUG"] = True


@app.route('/', methods=['GET'])
def home():
    return '''<h1>Homepage</h1>'''


@app.route('/nodedisplay', methods=['GET'])
def api_nodedisplay():
    try:
        start_time = time.time()
        apidata = fetchData.nodedisplay()
        end_time = time.time()
        if request.args.get('kp'):
            kp = list(request.args.get('kp').split(","))
        else:
            kp = None
        
        if request.args.get('p'):
            p = list(request.args.get('p').split(","))
        else:
            p = None
        #p = list(request.args.get('p', default = "").split(","))
        code = request.args.get('code')
        type = request.args.get('type')
        varprint = "<p>kp: " + str(kp) + "<br>" + "p: " + str(p) + "<br>" + "code: " + str(code) + "<br>" + "type: " + str(type) + "<br></p>"
        apidata = varprint + str(end_time - start_time) + " time " + apidata 

        return render_template("nodetemplate.html",content=apidata)
    except Exception as e:
        return str(e)

    
@app.route('/graphdisplay', methods=['GET'])
def graphdisplay():
    iframe_url = fetchData.graphdisplay()
    return f'<iframe src={iframe_url} name="iframe_a" height="100%" width="100%" title="Iframe Example"></iframe>'


@app.route('/htmldisplay', methods=['GET'])
def html_display():
    return render_template("test.html")
    

if __name__ == '__main__':
    app.debug = True
    app.run(host="0.0.0.0", port=5000) #host="0.0.0.0" will make the page accessable
                            #by going to http://[ip]:5000/ on any computer in 
                            #the network.


#app.run()
#76.251.77.235